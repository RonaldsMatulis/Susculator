


var img
var index
var iname
var price




function cart(event)
{
    


      
    // collecting information of checked box
    const item = event.currentTarget;
    const parnt = item.parentNode;
    let img = parnt.querySelector("img").src;
    let index = parnt.querySelector("h3").id;
    let iname = parnt.querySelector("h3").textContent;
    let price = parnt.querySelector(".price").textContent;
    console.log(price.length);
    
    console.log("item index",index + "\n" + "item name",iname + "\n" + "item price",price);

    if(item.checked)
        {
            console.log("box ticked", item.checked);
            console.log(index);

            if(document.querySelector(".pricetext") != null)
            {
                document.querySelector("h3[class=pricetext]").remove();
                document.querySelector("hr[class=pricetext]").remove();
            }

            //cloning template 
            const clone = document.querySelector("#template");         
            let template = clone.cloneNode(true);

            //making reciept entry
            var Windex = "W" + index
            const shroud = document.createElement("div");
            shroud.setAttribute("id", Windex);
            shroud.setAttribute("class", "wrapper")
            document.querySelector(".block").appendChild(shroud);
            document.getElementById(Windex).appendChild(template);
            const reciept = document.querySelector(".block #template");
            const recimg = reciept.querySelector("img").src = img;
            const recname = reciept.querySelector("h3").innerText = iname;
            const recprice = reciept.querySelector("p").innerText = "$" + price;
            reciept.querySelector("p").setAttribute("class", "recprice");

            reciept.id = "R" + index;
            reciept.className = "entry";
            

        }
    else
        {
            console.log("box unticked", item.checked);
            console.log(index);
            
            if(document.querySelector(".pricetext") != null)
            {
                document.querySelector("h3[class=pricetext]").remove();
                document.querySelector("hr[class=pricetext]").remove();
            }

            //deleting reciept enrty
                if(index == 0)
                    {
                        const Node = document.querySelector("[id='R0']");
                        const parent = Node.parentNode;
                        while (parent.lastElementChild) {
                        parent.removeChild(parent.lastElementChild);}
                        document.querySelector("#W0").remove()
                        console.log("case 0 triggered");
                    }
                else if(index == 1)
                    {
                        const Node = document.querySelector("[id='R1']");
                        const parent = Node.parentNode;
                        while (parent.lastElementChild) {
                        parent.removeChild(parent.lastElementChild);}
                        document.querySelector("#W1").remove()
                        console.log("case 1 triggered");
                    }
                    
                    

                else if(index == 2)
                    {
                        const Node = document.querySelector("[id='R2']");
                        const parent = Node.parentNode;
                        while (parent.lastElementChild) {
                        parent.removeChild(parent.lastElementChild);}
                        document.querySelector("#W2").remove()
                        console.log("case 2 triggered");
                    }


                else if(index == 3)
                    {
                        const Node = document.querySelector("[id='R3']");
                        const parent = Node.parentNode;
                        while (parent.lastElementChild) {
                        parent.removeChild(parent.lastElementChild);}
                        document.querySelector("#W3").remove()
                        console.log("case 3 triggered");
                    }


                else if(index == 4)
                    {
                        const Node = document.querySelector("[id='R4']");
                        const parent = Node.parentNode;
                        while (parent.lastElementChild) {
                        parent.removeChild(parent.lastElementChild);}
                        document.querySelector("#W4").remove()
                        console.log("case 4 triggered");
                    }
                    

                if(document.getElementById("template") == null)
                {
                    const clone = document.querySelector("#template");         
                    const template = clone.cloneNode(true);
                    document.querySelector(".right-cont .block").appendChild(template);
                    console.log("templated created");
                }
                    
        }
}

function calculate()
{
    if(document.querySelector(".pricetext") != null)
    {
        document.querySelector("h3[class=pricetext]").remove();
        document.querySelector("hr[class=pricetext]").remove();
    }
    
    const items = document.querySelectorAll(".wrapper");
    var prices = [];

    items.forEach(div => {const price = div.querySelector(".recprice"); prices.push(price.textContent.trim())});
    console.log(prices);

    for (let i = 0; i < prices.length; i++) {
        prices[i] = prices[i].replace(/\$/g, '');}

    const intprices = prices.map(num => parseFloat(num));

    const sum = intprices.reduce((total, num) => total + num, 0);
    console.log("this is the sum of prices >>>",sum);

    // const totalprice = "Total:" 

    const total = document.createElement("h3");
    const hr = document.createElement("hr");
    total.setAttribute("class", "pricetext");
    hr.setAttribute("class", "pricetext");
    total.innerText = "Total:" + " " + "$" + sum;
    document.querySelector(".block").appendChild(hr);
    document.querySelector(".block").appendChild(total);
    
}
